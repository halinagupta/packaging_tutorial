def addnumbers(x,y):
    return x+y
def subnumbers(x,y):
    return x-y
def multnumbers(x,y):
    return x*y