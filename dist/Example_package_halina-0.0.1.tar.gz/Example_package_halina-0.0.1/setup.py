from setuptools import setup,find_packages
setup(name="Example_package_halina",
      version='0.0.1',
      description='my first package',
      author='halina gupta',
      author_email='halina.gupta@gmail.com',
      packages=find_packages(),
      install_requires=[]   
)